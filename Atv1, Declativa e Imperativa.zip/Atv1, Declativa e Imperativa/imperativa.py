nome = input('Digite seu nome')
idade = int(input('Digite sua Idade'))

print(f'ola {nome}, você tem {idade} anos')
if idade >= 18:
    print('Você é maior de idade')
else:
    print('Você é menor de idade')    