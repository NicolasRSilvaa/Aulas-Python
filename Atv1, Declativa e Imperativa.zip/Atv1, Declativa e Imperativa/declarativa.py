numeros = [1,2,3,4,5,6]
quadrados = [x**2 for x in numeros]

print(quadrados)